export const personalInfo = {
  name: "Rodrigo Andrés Yalibat Del Cid",
  email: "contactoraydc@gmail.com",
  phone: "32409219",
  location: "9JC2+943, Caserío Panquiyob, Santa Cruz Verapaz, Alta Verapaz, Guatemala",
  profileDescription: "Estudiante de Ingeniería en Ciencias y Sistemas con experiencia comprobada en gestión comercial y liderazgo operativo. Mis fortalezas incluyen capacidad analítica, manejo de equipos y dominio de herramientas tecnológicas para la optimización de procesos.",
  languages: ["Español (nativo)", "Inglés (intermedio)"],
  availability: "Full-time (excepto sábados)",
  transport: "Público (licencia en trámite)"
};

export const technicalSkills = [
  { name: "Python", level: "Intermedio", percentage: 75 },
  { name: "C++", level: "Básico", percentage: 60 },
  { name: "Java/Kotlin", level: "Certificado", percentage: 70 },
  { name: "HTML5/CSS3", level: "Avanzado", percentage: 85 },
  { name: "JavaScript", level: "Intermedio", percentage: 75 },
  { name: "Excel Avanzado (VBA)", level: "Avanzado", percentage: 90 },
  { name: "Power BI", level: "Básico", percentage: 50 }
];

export const softSkills = [
  {
    name: "Liderazgo de Equipos",
    description: "Experiencia supervisando equipos de trabajo",
    icon: "👥"
  },
  {
    name: "Comunicación Efectiva", 
    description: "Habilidades de comunicación desarrolladas",
    icon: "💬"
  },
  {
    name: "Resolución de Problemas",
    description: "Capacidad analítica y pensamiento crítico", 
    icon: "🧩"
  },
  {
    name: "Adaptabilidad",
    description: "Flexibilidad ante cambios y nuevos retos",
    icon: "🔄"
  }
];

export const experience = [
  {
    position: "Encargado de Tienda",
    company: "Tecnomanía",
    location: "Tactic, Alta Verapaz",
    period: "Agosto 2023 - Marzo 2024",
    responsibilities: [
      "Supervisión directa de 2 empleados y coordinación de turnos",
      "Manejo de caja, inventario y métricas de venta",
      "Implementación de estrategias de servicio al cliente que mantuvieron niveles de venta estables",
      "Liderazgo del equipo enfocado en brindar experiencia de calidad al cliente"
    ],
    type: "latest"
  },
  {
    position: "Vendedor",
    company: "Tecnomanía", 
    location: "Tactic, Alta Verapaz",
    period: "Junio 2023 - Agosto 2023",
    responsibilities: [
      "Atención directa al cliente y asesoramiento en productos tecnológicos",
      "Cumplimiento de metas de venta y manejo de caja"
    ],
    achievement: "Ascendido a Encargado de Tienda tras 2 meses por desempeño destacado",
    type: "promotion"
  }
];

export const education = [
  {
    degree: "Ingeniería en Ciencias y Sistemas",
    institution: "Universidad Mariano Gálvez",
    period: "3er semestre - 2024 actual",
    type: "current"
  },
  {
    degree: "Bachiller en Ciencias y Letras con Orientación en Computación",
    institution: "Colegio La Inmaculada", 
    period: "2021-2022",
    type: "completed"
  }
];

export const certifications = [
  {
    name: "Introducción a Java y Kotlin",
    institution: "USAC, Programa de Cursos Libres",
    date: "Mayo 2025",
    duration: "16 horas",
    skills: ["Fundamentos de programación móvil", "Estructuras de datos", "Desarrollo de aplicaciones básicas en Java y Kotlin"],
    icon: "☕"
  },
  {
    name: "Protocolo, Etiqueta e Imagen Profesional", 
    institution: "USAC, Programa de Cursos Libres",
    date: "Mayo 2025",
    duration: "16 horas",
    skills: ["Técnicas de comunicación ejecutiva", "Manejo de imagen corporativa", "Protocolo en entornos empresariales"],
    icon: "👔"
  },
  {
    name: "Exportando Creatividad: Industrias Creativas en América Latina",
    institution: "BID-INTAL",
    date: "Agosto 2024", 
    duration: "8 horas",
    skills: [
      "Estrategias para la exportación de servicios en sectores audiovisuales, videojuegos e IA",
      "Conocimiento sobre Servicios Basados en Conocimiento (SBC) y su impacto en la economía regional",
      "Integración de tecnologías digitales en modelos de negocio creativos"
    ],
    credentialAvailable: true,
    icon: "💡"
  }
];

export const socialLinks = [
  { name: "Fiverr", url: "https://es.fiverr.com/ioraydc", icon: "💼", gradient: "from-blue-500 to-cyan-500" },
  { name: "GitHub", url: "https://github.com/Rod-Rod-Rod", icon: "👨‍💻", gradient: "from-gray-700 to-gray-600" },
  { name: "Instagram", url: "https://www.instagram.com/ra_ydc", icon: "📷", gradient: "from-pink-500 to-purple-600" }
];

export const projects = [
  {
    title: "Sistema de Gestión Web",
    description: "Aplicación web desarrollada con tecnologías modernas para gestión empresarial.",
    technologies: ["Python", "JavaScript", "HTML/CSS"],
    image: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    github: "#",
    demo: "#"
  },
  {
    title: "Aplicación Móvil",
    description: "App móvil desarrollada en Java/Kotlin con funcionalidades innovadoras.",
    technologies: ["Java", "Kotlin", "Android"],
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    github: "#",
    demo: "#"
  },
  {
    title: "Dashboard Analítico",
    description: "Panel de control con visualización de datos usando Power BI y Excel avanzado.",
    technologies: ["Power BI", "Excel VBA", "SQL"],
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    github: "#",
    demo: "#"
  }
];
