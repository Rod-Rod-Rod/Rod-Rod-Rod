import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { personalInfo, socialLinks } from "@/data/portfolioData";

export default function HeroSection() {
  const handleScrollToAbout = () => {
    const element = document.querySelector("#sobre-mi");
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="inicio" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-secondary to-primary"></div>
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080" 
          alt="Professional developer workspace" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="container mx-auto px-6 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-accent to-accent-cyan bg-clip-text text-transparent">
              Rodrigo Andrés
            </span>
            <br />
            <span className="text-foreground">Yalibat Del Cid</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-muted-foreground max-w-3xl mx-auto">
            {personalInfo.profileDescription}
          </p>
          
          {/* Social Links */}
          <div className="flex justify-center space-x-6 mb-12 flex-wrap gap-4">
            {socialLinks.map((link, index) => (
              <motion.a
                key={link.name}
                href={link.url}
                className={`bg-gradient-to-r ${link.gradient} px-6 py-3 rounded-full hover:scale-105 transition-transform flex items-center space-x-2`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <span>{link.icon}</span>
                <span>{link.name}</span>
              </motion.a>
            ))}
          </div>

          <button onClick={handleScrollToAbout} className="inline-block">
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              <ChevronDown className="text-3xl text-accent" />
            </motion.div>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
