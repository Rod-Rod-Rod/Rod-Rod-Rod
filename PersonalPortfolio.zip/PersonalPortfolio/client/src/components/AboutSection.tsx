import { motion } from "framer-motion";
import { personalInfo } from "@/data/portfolioData";

export default function AboutSection() {
  return (
    <section id="sobre-mi" className="py-20 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <span className="text-accent">Sobre</span> Mí
          </motion.h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <p className="text-lg leading-relaxed text-muted-foreground">
                {personalInfo.profileDescription}
              </p>
              <p className="text-lg leading-relaxed text-muted-foreground">
                Mi experiencia en el sector comercial me ha proporcionado valiosas habilidades de comunicación y liderazgo, mientras que mi formación académica me permite combinar la teoría con la práctica en el desarrollo de soluciones tecnológicas innovadoras.
              </p>
              
              <div className="grid grid-cols-2 gap-4 mt-8">
                <div className="glass-effect p-4 rounded-lg">
                  <h4 className="font-semibold text-accent mb-2">Ubicación</h4>
                  <p className="text-sm text-muted-foreground">Santa Cruz Verapaz, Alta Verapaz, Guatemala</p>
                </div>
                <div className="glass-effect p-4 rounded-lg">
                  <h4 className="font-semibold text-accent mb-2">Idiomas</h4>
                  <div className="text-sm text-muted-foreground">
                    {personalInfo.languages.map((lang, index) => (
                      <p key={index}>{lang}</p>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern technology programming setup" 
                className="rounded-xl shadow-2xl w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-accent/20 to-accent-cyan/20 rounded-xl"></div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
