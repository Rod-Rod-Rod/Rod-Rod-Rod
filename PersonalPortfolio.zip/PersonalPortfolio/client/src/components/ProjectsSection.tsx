import { motion } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";
import { projects } from "@/data/portfolioData";

export default function ProjectsSection() {
  const handleScrollToContact = () => {
    const element = document.querySelector("#contacto");
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="proyectos" className="py-20 bg-secondary">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl md:text-5xl font-bold text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <span className="text-accent">Mis</span> Proyectos
        </motion.h2>
        
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div 
                key={index}
                className="glass-effect rounded-xl overflow-hidden hover:scale-105 transition-transform"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2 text-[hsl(189,94%,43%)]">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech, techIndex) => (
                      <span 
                        key={techIndex}
                        className={`px-2 py-1 rounded text-xs ${
                          tech === 'Python' ? 'bg-accent' :
                          tech === 'JavaScript' ? 'bg-[hsl(189,94%,43%)]' :
                          tech === 'HTML/CSS' ? 'bg-purple-500' :
                          tech === 'Java' ? 'bg-orange-500' :
                          tech === 'Kotlin' ? 'bg-purple-600' :
                          tech === 'Android' ? 'bg-green-500' :
                          tech === 'Power BI' ? 'bg-yellow-500' :
                          tech === 'Excel VBA' ? 'bg-green-600' :
                          tech === 'SQL' ? 'bg-blue-500' :
                          'bg-gray-500'
                        } text-foreground`}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  <div className="flex space-x-4">
                    <a 
                      href={project.github} 
                      className="text-accent hover:text-[hsl(189,94%,43%)] transition-colors flex items-center"
                    >
                      <Github className="mr-1 w-4 h-4" />
                      GitHub
                    </a>
                    <a 
                      href={project.demo} 
                      className="text-accent hover:text-[hsl(189,94%,43%)] transition-colors flex items-center"
                    >
                      <ExternalLink className="mr-1 w-4 h-4" />
                      Demo
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Call to Action */}
          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <p className="text-muted-foreground mb-6">¿Interesado en colaborar en un proyecto?</p>
            <button 
              onClick={handleScrollToContact}
              className="bg-gradient-to-r from-accent to-[hsl(189,94%,43%)] px-8 py-3 rounded-full font-semibold hover:scale-105 transition-transform inline-block"
            >
              Contáctame
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
