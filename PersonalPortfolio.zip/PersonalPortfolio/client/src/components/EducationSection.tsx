import { motion } from "framer-motion";
import { GraduationCap, Laptop, Clock } from "lucide-react";
import { education, certifications } from "@/data/portfolioData";

export default function EducationSection() {
  return (
    <section id="educacion" className="py-20 bg-primary">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl md:text-5xl font-bold text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <span className="text-accent">Educación</span> y Certificaciones
        </motion.h2>
        
        <div className="max-w-6xl mx-auto">
          {/* Education */}
          <div className="mb-16">
            <motion.h3 
              className="text-2xl font-semibold mb-8 text-[hsl(189,94%,43%)] text-center"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Educación Formal
            </motion.h3>
            <div className="grid md:grid-cols-2 gap-8">
              {education.map((edu, index) => (
                <motion.div 
                  key={index}
                  className="glass-effect p-6 rounded-xl"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex items-center mb-4">
                    {edu.type === 'current' ? (
                      <GraduationCap className="text-3xl text-accent mr-4 w-8 h-8" />
                    ) : (
                      <Laptop className="text-3xl text-[hsl(189,94%,43%)] mr-4 w-8 h-8" />
                    )}
                    <div>
                      <h4 className="text-lg font-semibold">{edu.degree}</h4>
                      <p className={edu.type === 'current' ? 'text-accent' : 'text-[hsl(189,94%,43%)]'}>
                        {edu.institution}
                      </p>
                    </div>
                  </div>
                  <p className="text-muted-foreground">{edu.period}</p>
                </motion.div>
              ))}
            </div>
          </div>
          
          {/* Certifications */}
          <div>
            <motion.h3 
              className="text-2xl font-semibold mb-8 text-[hsl(189,94%,43%)] text-center"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              Certificaciones
            </motion.h3>
            <div className="grid md:grid-cols-3 gap-8">
              {certifications.map((cert, index) => (
                <motion.div 
                  key={index}
                  className="glass-effect p-6 rounded-xl hover:scale-105 transition-transform"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-2">{cert.icon}</div>
                    <h4 className="font-semibold text-lg">{cert.name}</h4>
                    <p className="text-accent text-sm">{cert.institution} - {cert.date}</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p className="flex items-center">
                      <Clock className="mr-2 text-accent w-4 h-4" />
                      {cert.duration}
                    </p>
                    <div className="text-xs">
                      {cert.skills.map((skill, idx) => (
                        <p key={idx} className="mb-1">• {skill}</p>
                      ))}
                    </div>
                    {cert.credentialAvailable && (
                      <p className="text-accent text-xs font-medium">
                        Credencial verificable disponible
                      </p>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
