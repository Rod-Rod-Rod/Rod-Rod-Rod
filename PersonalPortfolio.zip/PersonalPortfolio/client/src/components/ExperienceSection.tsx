import { motion } from "framer-motion";
import { CheckCircle, Star } from "lucide-react";
import { experience } from "@/data/portfolioData";

export default function ExperienceSection() {
  return (
    <section id="experiencia" className="py-20 bg-secondary">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl md:text-5xl font-bold text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <span className="text-accent">Experiencia</span> Laboral
        </motion.h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-accent"></div>
            
            {/* Experience Items */}
            <div className="space-y-12">
              {experience.map((job, index) => (
                <motion.div 
                  key={index}
                  className="relative flex items-start"
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                >
                  <div className={`absolute left-6 w-4 h-4 rounded-full border-4 border-secondary ${
                    job.type === 'latest' ? 'bg-accent' : 'bg-cyan-400'
                  }`}></div>
                  <div className="ml-20 glass-effect p-6 rounded-xl w-full">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-cyan-400">{job.position}</h3>
                        <p className="text-accent font-medium">{job.company} - {job.location}</p>
                      </div>
                      <span className={`text-sm px-3 py-1 rounded-full mt-2 md:mt-0 ${
                        job.type === 'latest' ? 'bg-accent' : 'bg-cyan-400'
                      } text-foreground`}>
                        {job.period}
                      </span>
                    </div>
                    <ul className="space-y-2 text-muted-foreground">
                      {job.responsibilities.map((responsibility, idx) => (
                        <li key={idx} className="flex items-start">
                          <CheckCircle className={`mr-2 mt-1 w-4 h-4 ${
                            job.type === 'latest' ? 'text-accent' : 'text-cyan-400'
                          }`} />
                          {responsibility}
                        </li>
                      ))}
                      {job.achievement && (
                        <li className="flex items-start">
                          <Star className="mr-2 mt-1 w-4 h-4 text-yellow-400" />
                          <strong>Logro:</strong> {job.achievement}
                        </li>
                      )}
                    </ul>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
