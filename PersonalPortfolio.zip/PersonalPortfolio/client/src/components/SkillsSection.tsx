import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { technicalSkills, softSkills } from "@/data/portfolioData";

export default function SkillsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="habilidades" className="py-20 bg-primary" ref={sectionRef}>
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl md:text-5xl font-bold text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <span className="text-accent">Habilidades</span>
        </motion.h2>
        
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Technical Skills */}
            <motion.div 
              className="glass-effect p-8 rounded-xl"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-2xl font-semibold mb-8 text-cyan-400">
                <span className="mr-3">💻</span>Habilidades Técnicas
              </h3>
              
              <div className="space-y-6">
                {technicalSkills.map((skill, index) => (
                  <motion.div 
                    key={skill.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-accent">{skill.level}</span>
                    </div>
                    <div className="skill-bar bg-muted h-3 rounded-full">
                      <div 
                        className={`skill-bar-fill h-full rounded-full transition-all ease-in-out ${isVisible ? 'animate' : ''}`}
                        style={{ 
                          width: isVisible ? `${skill.percentage}%` : '0%',
                          transitionDuration: '2s',
                          '--skill-width': `${skill.percentage}%` 
                        } as any}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            {/* Soft Skills */}
            <motion.div 
              className="glass-effect p-8 rounded-xl"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <h3 className="text-2xl font-semibold mb-8 text-cyan-400">
                <span className="mr-3">👥</span>Habilidades Blandas
              </h3>
              
              <div className="grid grid-cols-2 gap-6">
                {softSkills.map((skill, index) => (
                  <motion.div 
                    key={skill.name}
                    className="text-center p-6 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.05 }}
                  >
                    <div className="text-3xl mb-4">{skill.icon}</div>
                    <h4 className="font-semibold mb-2">{skill.name}</h4>
                    <p className="text-sm text-muted-foreground">{skill.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
